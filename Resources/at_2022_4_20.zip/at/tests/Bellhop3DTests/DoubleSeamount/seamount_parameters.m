seamount.tip_x(1) = 3500;
seamount.tip_y(1) = 1000;
seamount.tip_z(1) = 200;
seamount.slope(1) = 500/2000;
seamount.radius(1) = 2500; 

seamount.tip_x(2) = 3500;
seamount.tip_y(2) = -1000;
seamount.tip_z(2) = 200;
seamount.slope(2) = 500/2000;
seamount.radius(2) = 2500; 
